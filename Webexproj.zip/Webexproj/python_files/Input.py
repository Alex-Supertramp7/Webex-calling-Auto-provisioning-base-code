#Main Inputs

orgId = "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU"

bearerToken = "MTI0YWI0YjctZmFhOC00ODlkLTgyNDAtYzI2Y2JhOWMwNmNlN2FhMzBmNDEtYWRh_P0A1_e4d60de5-4583-4d6f-bf65-4a1f7724bf6e"

# Location API Request URLs
GetAllLocation = "https://webexapis.com/v1/locations"
CreateLocationAPIUrl = "https://webexapis.com/v1/locations?"
CreateLocation = CreateLocationAPIUrl + orgId

# Location Inputs
CreateLocationdata = {
    "name": "Test_location",
    "timezone": "America/Chicago",
    "announcementLanguage": "en_us",
    "preferredLanguage": "en_us",
    "address": {
        "address1": "123 Some St.",
        "address2": "suite 123",
        "city": "Supercity",
        "state": "Goodstate",
        "postalCode": "12345",
        "country": "US"
    }
}

NumbersData = {
    "phoneNumbers": ["+12145551060","+12145551061","+12145551062","+12145551063","+12145551064"],
     "state": "ACTIVE"
}

# create_Trunk_data 148 
# Update_Location_for_calling 198

#Org Inputs

GetOrgDetailURL = "https://webexapis.com/v1/organizations"
#orgId = "e4d60de5-4583-4d6f-bf65-4a1f7724bf6e"
GetOrgDetail = GetOrgDetailURL + orgId



ListLocationsofOrgUrl = "https://webexapis.com/v1/locations?orgId="
ListLocationsofOrg = ListLocationsofOrgUrl + orgId

# Create Subscriber/user in the Org

CreateWholsaleSubscriber = "https://webexapis.com/v1/wholesale/subscribers"

CreateWholsaleSubscriberData = {
  "customerId": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
  "email": "Alex5@gmail.com",
  "package": "webex_suite",
  "provisioningParameters": {
    "firstName": "Alex",
    "lastName": "stp5",
    "primaryPhoneNumber": "+12145551067",
    "extension": "1067",
    "locationId": "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzliMjdkYmNhLTI1YmYtNGFlMC04NGMwLThjMzY3NzIwYmZiMQ"
  }
}

#Assign number to Location

AssignNumberToLocationURL = "https://webexapis.com/v1/telephony/config/locations/"
LocationIDNumberAdd = "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzliMjdkYmNhLTI1YmYtNGFlMC04NGMwLThjMzY3NzIwYmZiMQ/numbers?orgId="

AssignNumberToLocation = AssignNumberToLocationURL + LocationIDNumberAdd + orgId



#Create a new org
CreateNewOrg = "https://webexapis.com/v1/wholesale/customers"

# Create a new people

CreateNewPeople = "https://webexapis.com/v1/people?callingData=true"

CreateNewPeopleData = {
  "emails": [
    "Alexstp8@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": "408 526 7223"
    }
  ],
  "extension": "7223",
  "locationId": "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzliMjdkYmNhLTI1YmYtNGFlMC04NGMwLThjMzY3NzIwYmZiMQ",
  "displayName": "Alex Stp8",
  "firstName": "Alex",
  "lastName": "stp8",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
 #
 #
  "department": "Sales",
  #"manager": "John Duarte",
  #"managerId": "Y2lzY29zcGFyazovL3VzL1BFT1BMRS80ZGEzYTI0OC05YjBhLTQxMDgtODU0NC1iNTQwMzEyZTU2M2E",
 # "title": "GM",
  #"addresses": [
  #  {
   #   "type": "work",
   #   "country": "US",
   #   "locality": "Milpitas",
   #   "region": "California",
    #  "streetAddress": "1099 Bird Ave.",
  #    "postalCode": "99212"
   # }
 # ],
  "siteUrls": [
    "mysite.webex.com#attendee"
  ]
}

#TC - 2

List_People_Link = "https://webexapis.com/v1/people?orgId="
ListPeople = List_People_Link + orgId

Delete_PeopleURL = "https://webexapis.com/v1/people/"
PeopleID = "Y2lzY29zcGFyazovL3VzL1BFT1BMRS9jNWM4MjNjNy0zOTk1LTRkZDMtODRiYy0xM2I2YmRjNGY2YTk"
Delete_People = Delete_PeopleURL + PeopleID

Delete_Number_From_Location_URL = "https://webexapis.com/v1/telephony/config/locations/"
LocationID_Belongs_To_numberDelete = "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzliMjdkYmNhLTI1YmYtNGFlMC04NGMwLThjMzY3NzIwYmZiMQ/numbers?orgId="
Delete_Numbers_From_Location = Delete_Number_From_Location_URL + LocationID_Belongs_To_numberDelete + orgId

NumbersToDelete = {
    "phoneNumbers": [
        "+12145551067"
    ],
     "state": "ACTIVE"
}

#TC 4 
#https://webexapis.com/v1/telephony/config/locations/{locationId}/autoAttendants
Create_AA_Url = "https://webexapis.com/v1/telephony/config/locations/"
LocationIDforAA = "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzliMjdkYmNhLTI1YmYtNGFlMC04NGMwLThjMzY3NzIwYmZiMQ/autoAttendants"
AA = "?orgId=Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU"
Create_AA = Create_AA_Url + LocationIDforAA# + AA

AA_Payload = {
    "name": "AA_Test1",
    "phoneNumber": "+12145551060",
    "extension": "9060",
    "firstName": "AA1",
    "lastName": "Test",
    "languageCode": "en_us",
    "businessSchedule": "AUTOATTENDANT-BUSINESS-HOURS",
    "holidaySchedule": "AUTOATTENDANT-HOLIDAY",
    "extensionDialing": "ENTERPRISE",
    "nameDialing": "ENTERPRISE",
    "timeZone": "America/Texas",
    "businessHoursMenu": {
        "greeting": "DEFAULT",
        "audioAnnouncementFile": {
             "id": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
             "fileName": "AUDIO_FILE.wav",
             "mediaFileType": "WAV",
             "level": "ORGANIZATION"
        },
        "extensionEnabled": "true",
        "keyConfigurations": [
            {
                "key": "0",
                "action": "EXIT"
            },
            {
                "key": "1",
                "action": "TRANSFER_WITHOUT_PROMPT",
                "value": "+12145551061"
            },
            {
                "key": "2",
                "action": "TRANSFER_WITH_PROMPT",
                "value": "+12145551062"
            },
            {
                "key": "3",
                "action": "EXTENSION_DIALING"
            },
            {
                "key": "4",
                "action": "TRANSFER_TO_MAILBOX",
                "value": "+12145551063"
            },
            {
                 "key": "5",
                 "action": "PLAY_ANNOUNCEMENT",
                 "audioAnnouncementFile": {
                     "id": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
                     "fileName": "AUDIO_FILE.wav",
                     "mediaFileType": "WAV",
                     "level": "ORGANIZATION"
                 }
            },
            {
                "key": "6",
                "action": "REPEAT_MENU"
            }
        ]
    },
    "afterHoursMenu": {
        "greeting": "DEFAULT",
        "audioAnnouncementFile": {
             "id": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
             "fileName": "AUDIO_FILE.wav",
             "mediaFileType": "WAV",
             "level": "ORGANIZATION"
        },
        "extensionEnabled": "true",
        "keyConfigurations": [
            {
                "key": "0",
                "action": "EXIT"
            },
            {
                 "key": "1",
                 "action": "PLAY_ANNOUNCEMENT",
                 "audioAnnouncementFile": {
                     "id": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi9lNGQ2MGRlNS00NTgzLTRkNmYtYmY2NS00YTFmNzcyNGJmNmU",
                     "fileName": "AUDIO_FILE.wav",
                     "mediaFileType": "WAV",
                     "level": "ORGANIZATION"
                 }
            }
        ]
    }
}


# Location Inputs
CreateLocationdata = {
    "name": "Test_location",
    "timezone": "America/Chicago",
    "announcementLanguage": "en_us",
    "preferredLanguage": "en_us",
    "address": {
        "address1": "123 Some St.",
        "address2": "suite 123",
        "city": "Supercity",
        "state": "Goodstate",
        "postalCode": "12345",
        "country": "US"
    }
}


#Enable webex calling for the location

Enable_calling_for_location_Data = { 
    "id": "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzg0ODlkZmMzLWVkNDMtNDk2Mi04NjI2LTZiNDVmNzMxYjAzYQ",
    "name": "AA1 hhhhh",
    "timeZone": "America/Chicago",
    "announcementLanguage": "fr_fr",
    "preferredLanguage": "en_us",
    "address": {
        "address1": "123 Some St.",
            "address2": "suite 123",
            "city": "Supercity",
            "state": "Goodstate",
            "postalCode": "12345",
            "country": "US"
    }}


Enable_Location_calling_url = "https://webexapis.com/v1/telephony/config/locations?orgId="
Enable_Location_calling = Enable_Location_calling_url + orgId


#Webex Calling Trunk

Create_trunk_url = "https://webexapis.com/v1/telephony/config/premisePstn/trunks?orgId="
Create_trunk = Create_trunk_url + orgId

Create_trunk_data = {
  "name": "trunk_1",
  "locationId": "Y2lzY29zcGFyazovL3VzL0xPQ0FUSU9OLzU2NGY1MjEyLWU3NmQtNGUzZC04NGYwLTFjM2E0YjI5MmFlYQ",
  "password": "password",
  "dualIdentitySupportEnabled": True,
  "trunkType": "REGISTERING",
  "deviceType": "Cisco Unified Border Element",
  "address": "lgw1.london",
  "domain": "acme.corp",
  "port": 5061,
  "maxConcurrentCalls": 10
}