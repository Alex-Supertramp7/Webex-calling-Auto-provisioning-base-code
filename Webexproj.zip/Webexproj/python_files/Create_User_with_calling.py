import requests
import Input

Create_User_calling_data = Input.CreateNewPeopleData
Create_user_with_calling = Input.CreateNewPeople
bearerToken = Input.bearerToken

headers = { 'Authorization' : f'Bearer {bearerToken}'}
response = requests.post(Create_user_with_calling, json=Create_User_calling_data, headers=headers)

if response.status_code ==200:
    print(f"User with calling created successfully : {response.status_code} & {response.text}")

else:
    print(f"Failed to create a user : {response.status_code} & {response.text}")