import Input
import requests

Create_trunk = Input.Create_trunk
Create_trunk_data = Input.Create_trunk_data
bearerToken = Input.bearerToken

headers = {'Authorization' : f'Bearer {bearerToken}'}

response = requests.post(Create_trunk, json=Create_trunk_data, headers=headers)

if response.status_code == 201:
    print (f"Trunk created successfully {response.text}")

else:
    print(f"Trunk creation failed - (Please check if the calling enable for the location) {response.status_code}:{response.text}")