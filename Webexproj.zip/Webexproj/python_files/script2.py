import requests
import Input

CreateNewPeople = Input.CreateNewPeople
bearerToken = Input.bearerToken
CreateNewPeopleData = Input.CreateNewPeopleData

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.post(CreateNewPeople, json=CreateNewPeopleData, headers=headers)

if response.status_code == 200:
    print(f"Subscriber created successfully {response.text}")
else:
    print(f"Request failed with status code {response.status_code}")
    print(f"Error message {response.content}")