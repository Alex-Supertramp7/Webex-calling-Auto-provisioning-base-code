import requests
import json

bearerToken = "MWM3ZDg1NzEtYjUzZC00YWI2LTk4OTYtNDExZGE3ZmIyMjE1NDJhYzNiMTgtNjM3_P0A1_e4d60de5-4583-4d6f-bf65-4a1f7724bf6e"
List_license = "https://webexapis.com/v1/licenses"
headers = {'Authorization': f'Bearer {bearerToken}'}


CreateNewPeople = "https://webexapis.com/v1/people?callingData=true"
CreateNewPeopleData = {
  "emails": [
    "Alexstp2@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": PhoneNumber2
    }
  ],
  "extension": "1062",
  "locationId": Location_id,
  "displayName": "Alex Stp2",
  "firstName": "Alex",
  "lastName": "stp2",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": orgId,
  "department": "Sales",
  "siteUrls": [
    "mysite.webex.com#attendee"
  ],
  "licenses": [
    Webex_calling_License
  ],
}

Create_User_calling_data = CreateNewPeopleData
Create_user_with_calling = CreateNewPeople
bearerToken = Input.bearerToken

headers = { 'Authorization' : f'Bearer {bearerToken}'}
response = requests.post(Create_user_with_calling, json=Create_User_calling_data, headers=headers)

if response.status_code ==200:
    print(f"User with calling created successfully : {response.status_code}")
    Created_User = (response.text)
else:
    print(f"Failed to create a user : {response.status_code} & {response.text}")


