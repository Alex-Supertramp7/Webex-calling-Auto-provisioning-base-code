import requests
import Input
import Main

Enable_Location_calling = Input.Enabele_Location_calling
bearerToken = Input.bearerToken
Enabele_Location_calling_data = Main.final

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.post(Enable_Location_calling, json=Enabele_Location_calling_data, headers=headers)

if response.status_code== 201:
    print(f"Webex calling enabled for for the Location :{response.text}")

else:
    print(f"Failed to enable Webex call for the Location : {response.status_code} & {response.text}")

