import requests
import Input

CreateLocation = Input.CreateLocation
bearerToken = Input.bearerToken
CreateLocationdata = Input.CreateLocationdata

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.post(CreateLocation, json=CreateLocationdata, headers=headers)

if response.status_code == 201:
    print(f"Location created successfully : {response.text}")
else:
    print(f"Request failed with status code {response.status_code}")
    print(f"Error message {response.content}")