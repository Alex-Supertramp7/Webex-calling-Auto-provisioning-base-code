import requests
import Input

GetOrgDetailURL = Input.GetOrgDetailURL
bearerToken = Input.bearerToken

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.get(GetOrgDetailURL, headers=headers)

if response.status_code == 200:
    print(f"Location Info fetched successfully {response.text}")
else:
    print(f"Request failed with status code {response.status_code}")
    print(f"Error message {response.content}")