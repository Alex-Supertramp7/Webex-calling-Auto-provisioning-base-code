import requests
import Input
import json

CreateLocation = Input.CreateLocation
bearerToken = Input.bearerToken
CreateLocationdata = Input.CreateLocationdata

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.post(CreateLocation, json=CreateLocationdata, headers=headers)

json_output=None
if response.status_code == 201:
    print(f"Location created successfully")
    json_output = (response.text)
    #print(json)
else:
    print(f"Failed to create a location {response.status_code} - {response.content}")

print(json_output)

input_data_for_enable_calling = json_output

data = json.loads(input_data_for_enable_calling)

# Extract and transform the desired information
id_parts = data["id"].split("/")
output_data = {
    "id": id_parts[-1],  # Use the last part of the ID
    "name": data["name"],
    "timeZone": data["timeZone"],
    "announcementLanguage": "fr_fr",  # You can customize this value
    "preferredLanguage": data["preferredLanguage"],
    "address": {
        "address1": data["address"]["address1"],
        "address2": data["address"]["address2"],
        "city": data["address"]["city"],
        "state": data["address"]["state"],
        "postalCode": data["address"]["postalCode"],
        "country": data["address"]["country"]
    }
}

Enable_calling_for_location_Data = json.dumps(output_data, indent=4)

print(Enable_calling_for_location_Data)

orgId = data["orgId"]
Location_id = output_data["id"]
Location_name = output_data["name"]
preferredLanguage = output_data["preferredLanguage"]

# Below code will enable the calling for the created location


Enable_Location_calling_url = "https://webexapis.com/v1/telephony/config/locations?orgId="
Enable_Location_calling = Enable_Location_calling_url + orgId

response = requests.post(Enable_Location_calling, json=Enable_calling_for_location_Data, headers=headers)

if response.status_code== 201:
    print(f"Webex calling enabled for for the Location :{response.text}")

else:
    print(f"Failed to enable Webex call for the Location : {response.status_code} & {response.text}")


# Below code will add the numbers to the created location

AssignNumberToLocationURL = "https://webexapis.com/v1/telephony/config/locations/"
LocationIDNumberAdd = Location_id + "/numbers?orgId="

AssignNumberToLocation = AssignNumberToLocationURL + LocationIDNumberAdd + orgId
NumbersData = Input.NumbersData

response = requests.post(AssignNumberToLocation, json=NumbersData, headers=headers)

if response.status_code == 201:
    print(f"Numbers Assigned to Location successfully {response.text}")
else:
    print(f"Failed to assign number to the location : {response.status_code}")
    print(f"Error message : {response.content}")

# Below code will list the numbers & add to the variables

Get_Numbers_for_location_url = "https://webexapis.com/v1/telephony/config/numbers?locationId="
Get_Numbers_for_location = Get_Numbers_for_location_url + Location_id

response = requests.get(Get_Numbers_for_location, headers=headers)

if response.status_code == 200:
    Numbers_In_location_Data = (response.text)
    print(f"Find the numbers info that assigned to the location : {Location_name}{response.text}")

else:
    print(f"Failed to list the numbers info assigned to the location : {response.text}")


Location_Number_parse = json.loads(Numbers_In_location_Data)

phone_numbers = [entry["phoneNumber"] for entry in Location_Number_parse["phoneNumbers"]]

phn_ls = {}
for i, phone_number in enumerate(phone_numbers, start=0):
    phn_ls[f'PhoneNumber{i}'] = phone_number

Phone_number_list = phn_ls


print(Phone_number_list)

PhoneNumber0 = Phone_number_list["PhoneNumber0"]
PhoneNumber1 = Phone_number_list["PhoneNumber1"]
PhoneNumber2 = Phone_number_list["PhoneNumber2"]
PhoneNumber3 = Phone_number_list["PhoneNumber3"]
PhoneNumber4 = Phone_number_list["PhoneNumber4"]

# Below code will activate the numbers added to the location
Acivate_numbers_url = "https://webexapis.com/v1/telephony/config/locations/"

Acivate_numbers = Acivate_numbers_url + Location_id + "/numbers"
Acivate_numbers_data =({
    "phoneNumbers": [
        PhoneNumber0,
        PhoneNumber1,
        PhoneNumber2,
        PhoneNumber3,
        PhoneNumber4
    ]})

response = requests.put(Acivate_numbers, json=Acivate_numbers_data, headers=headers)

if response.status_code==204:
    print(f"Numbers activate successfully : {response.status_code}{response.text}{Phone_number_list}")

else:
    print(f"Failed to activate numbers : {response.status_code}{response.text}")

# Below code will create a Registeration Trunk to the created location
    
Create_Trunk = "https://webexapis.com/v1/telephony/config/premisePstn/trunks?orgId=" + orgId

create_Trunk_data = {
  "dualIdentitySupportEnabled": 1,
  "name": "Reg1",
  "locationId": Location_id,
  "password": "password",
  "trunkType": "REGISTERING"
}

response = requests.post(Create_Trunk, json=create_Trunk_data, headers=headers)

if response.status_code == 201:
    print(f"Trunk created at Location successfully {response.text}")
else:
    print(f"Request failed with status code : {response.status_code}")
    print(f"Error message : {response.content}")

# Below code to get the Trunk info
    
Get_trunk_info_for_location_url = "https://webexapis.com/v1/telephony/config/premisePstn/trunks?locationName="
Get_trunk_info_for_location = Get_trunk_info_for_location_url + Location_name

response = requests.get(Get_trunk_info_for_location, headers=headers)

Trunk_output = None
if response.status_code == 200:
    print(f"Find the created trunk info : {response.status_code}")
    Trunk_output = (response.text)
else:
    print(f"Failed to create a trunk : {response.text}")

print(f"Trunk_output : {Trunk_output}")


Trunk_Input_data_for_calling = json.loads(Trunk_output)

Trunk_id = Trunk_Input_data_for_calling["trunks"][0]["id"]
Trunk_name = Trunk_Input_data_for_calling["trunks"][0]["name"]
Location_id = Trunk_Input_data_for_calling["trunks"][0]["location"]["id"]
Location_name = Trunk_Input_data_for_calling["trunks"][0]["location"]["name"]
In_use = Trunk_Input_data_for_calling["trunks"][0]["inUse"]
Trunk_type = Trunk_Input_data_for_calling["trunks"][0]["trunkType"]
Is_restricted = Trunk_Input_data_for_calling["trunks"][0]["isRestrictedToDedicatedInstance"]

# Below code will enable calling for the particular location

Update_Location_for_calling_url = "https://webexapis.com/v1/telephony/config/locations/"

Update_Location_for_calling = Update_Location_for_calling_url + Location_id + "?orgId=" + orgId

Update_Location_for_calling_data = {
    "announcementLanguage": preferredLanguage,
    "outsideDialDigit": "9",
    "callingLineId": {
        "name": "Test",
        "phoneNumber": PhoneNumber0
    },
    "connection": {
        "type": "TRUNK",
        "id": Trunk_id
    },
    "enforceOutsideDialDigit": True
}

response = requests.put(Update_Location_for_calling, json=Update_Location_for_calling_data, headers=headers)

if response.status_code == 200 or 204:
    print(f"Calling enabled for the location successfully : {response.status_code} - {response.text}")
else:
    print(f"Failed to enable Calling for the location : {response.status_code} - {response.text}")

# Below code will list the License present in the Location
List_license = "https://webexapis.com/v1/licenses"
response = requests.get(List_license, headers=headers)
if response.status_code==200:
    print(f"success : {response.status_code}")
    #print(response.text)
    License_list_raw_data = (response.text)
    #print(License_list_raw_data)

else:
    print(f"Failed : {response.status_code}, {response.content}")
Webex_calling_License_data = json.loads(License_list_raw_data)
print(f"License list : {Webex_calling_License_data}")

Webex_calling_License = None
for item in Webex_calling_License_data['items']:
    if item['name'] == 'Webex Calling - Professional':
        Webex_calling_License = item['id']
        break

print(Webex_calling_License)

CreateNewPeople = "https://webexapis.com/v1/people?callingData=true"
CreateNewPeopleData = {
  "emails": [
    "Alexstp2@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": PhoneNumber2
    }
  ],
  "extension": "1062",
  "locationId": Location_id,
  "displayName": "Alex Stp2",
  "firstName": "Alex",
  "lastName": "stp2",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": orgId,
  "department": "Sales",
  "siteUrls": [
    "mysite.webex.com#attendee"
  ],
  "licenses": [
    Webex_calling_License
  ],
}

Create_User_calling_data = CreateNewPeopleData
Create_user_with_calling = CreateNewPeople

headers = { 'Authorization' : f'Bearer {bearerToken}'}
response = requests.post(Create_user_with_calling, json=Create_User_calling_data, headers=headers)

if response.status_code ==200:
    print(f"User with calling created successfully : {response.status_code}")
    Created_User = (response.text)
else:
    print(f"Failed to create a user : {response.status_code} & {response.text}")

CreateNewPeople = "https://webexapis.com/v1/people?callingData=true"
users_data  = [{
  "emails": [
    "Alexstp1@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": PhoneNumber1
    }
  ],
  "extension": "1061",
  "locationId": Location_id,
  "displayName": "Alex Stp1",
  "firstName": "Alex",
  "lastName": "stp1",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": orgId,
  "department": "Sales",
  "siteUrls": [
    "mysite.webex.com#attendee"
  ],
  "licenses": [
    Webex_calling_License
  ]},
  {"emails": [
      "Alexstp2@gmail.com"
    ],
    "phoneNumbers": [
      {
        "type": "work",
        "value": PhoneNumber2
      }
    ],
    "extension": "1062",
    "locationId": Location_id,
    "displayName": "Alex Stp2",
    "firstName": "Alex",
    "lastName": "stp2",
    "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
    "orgId": orgId,
    "department": "Sales",
    "siteUrls": [
      "mysite.webex.com#attendee"
    ],
    "licenses": [
      Webex_calling_License
    ]}]

CreateNewPeople = "https://webexapis.com/v1/people?callingData=true"
users_data  = [{
  "emails": [
    "Alexstp1@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": PhoneNumber1
    }
  ],
  "extension": "1061",
  "locationId": Location_id,
  "displayName": "Alex Stp1",
  "firstName": "Alex",
  "lastName": "stp1",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": orgId,
  "department": "Sales",
  "siteUrls": [
    "mysite.webex.com#attendee"
  ],
  "licenses": [
    Webex_calling_License
  ]},
{"emails": [
    "Alexstp2@gmail.com"
  ],
  "phoneNumbers": [
    {
      "type": "work",
      "value": PhoneNumber2
    }
  ],
  "extension": "1062",
  "locationId": Location_id,
  "displayName": "Alex Stp2",
  "firstName": "Alex",
  "lastName": "stp2",
  "avatar": "https://1efa7a94ed21783e352-c62266528714497a17239ececf39e9e2.ssl.cf1.rackcdn.com/V1~54c844c89e678e5a7b16a306bc2897b9~wx29yGtlTpilEFlYzqPKag==~1600",
  "orgId": orgId,
  "department": "Sales",
  "siteUrls": [
    "mysite.webex.com#attendee"
  ],
  "licenses": [
    Webex_calling_License
  ]}]
for user_index, user_data in enumerate(users_data, start=1):
    Create_User_calling_data = user_data
    Create_user_with_calling = CreateNewPeople
    bearerToken = Input.bearerToken

    headers = {'Authorization': f'Bearer {bearerToken}'}
    response = requests.post(Create_user_with_calling, json=Create_User_calling_data, headers=headers)

    if response.status_code == 200:
        print(f"User {user_index} with calling created successfully: {response.status_code}")
        Created_User = response.text
    else:
        print(f"Failed to create user {user_index}: {response.status_code} & {response.text}")