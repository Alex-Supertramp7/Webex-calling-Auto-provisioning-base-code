import requests
import Input
import json


GetLocation = Input.GetAllLocation
bearerToken = Input.bearerToken

headers = {'Authorization' : f'Bearer {bearerToken}'}
response = requests.get(GetLocation, headers=headers)
data=None
if response.status_code==200:
    #output = response.json()
    print(f"Location Listed successfully : {response.status_code} OK")
    #print(output)
    data = json.loads(response.text)
    # final_data = {item["id"]: item for item in data["items"]}
    # final_json = json.dumps(final_data, indent=4)
    # print(f"{final_json}")
    # with open("D:\Flask\Webexproj\python_files\Location_database.py", "w") as file:
    #     file.write(final_json)
else:
    print(f"Failed to list the location : {response.status_code} & {response.text}")

print(data)
