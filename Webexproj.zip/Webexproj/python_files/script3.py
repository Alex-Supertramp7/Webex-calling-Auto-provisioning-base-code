import os
import requests
import Input

AssignNumberToLocation = Input.AssignNumberToLocation
bearerToken = Input.bearerToken
NumbersData = Input.NumbersData

headers = {'Authorization': f'Bearer {bearerToken}'}

response = requests.post(AssignNumberToLocation, json=NumbersData, headers=headers)

if response.status_code == 201:
    print(f"Numbers Assigned to Location successfully {response.text}")
else:
    print(f"Request failed with status code : {response.status_code}")
    print(f"Error message : {response.content}")