a=20
b=85
c=45

if (a>b) & (a>c):
    print("A is greater")

elif (b>a) & (b>c):
    print("B is greater")

else:
    print("c is greater")