# app.py
# app.py
from flask import Flask, render_template, request
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('Org_form.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Execute the external Python script from the python_files folder
        script_path = 'python_files/Get_Org_Info.py'
        process = subprocess.Popen(['python', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()

        if process.returncode == 0:
            return render_template('result1.html', output=output.decode('utf-8'))
        else:
            return render_template('result1.html', output=f"Error executing script: {error.decode('utf-8')}")
        
@app.route('/Get_All_Location_Data', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Execute the external Python script from the python_files folder
        script_path = 'python_files/Get_Location_info.py'
        process = subprocess.Popen(['python', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()

        if process.returncode == 0:
            return render_template('All_location_list.html', output=output.decode('utf-8'))
        else:
            return render_template('All_location List.html', output=f"Error executing script: {error.decode('utf-8')}")

if __name__ == '__main__':
    app.run(debug=True)

