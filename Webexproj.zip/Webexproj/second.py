from flask import Flask,redirect,url_for,render_template
import subprocess

second = Blueprint("Second",__name__,)
app = Flask(__name__)