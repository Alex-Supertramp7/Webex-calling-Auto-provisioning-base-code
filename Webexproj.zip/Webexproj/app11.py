from flask import Flask, render_template, request
import os
import traceback
import json
import re
from importlib.machinery import SourceFileLoader
import ast


app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/execute_scripts', methods=['POST'])
def execute_scripts():
    script_filenames = ['script1.py', 'script2.py', 'script3.py']
    results = []

    for script_filename in script_filenames:
        script_path = os.path.join(os.path.dirname(__file__), 'python_files', script_filename)
        result = {
            'script_name': script_filename,
            'success': True,
            'message': ''
        }

        try:
            with open(script_path, 'r') as script_file:
                script_code = script_file.read()
                exec_result = {}
                try:
                    exec(script_code, globals(), exec_result)
                    
                    # Customize messages based on the script
                    if script_filename == 'script1.py':
                        result['message'] = "Location created successfully."
                    elif script_filename == 'script2.py':
                        result['message'] = "User created successfully."
                    elif script_filename == 'script3.py':
                        result['message'] = "Number added successfully."
                except Exception as e:
                    result['success'] = False
                    result['message'] = f"Execution error: {type(e).__name__} - {str(e)}"
                    traceback.print_exc()
        except FileNotFoundError:
            result['success'] = False
            result['message'] = "Script not found."

        results.append(result)

    return render_template('result.html', results=results)

@app.route('/update_location_data', methods=['POST'])
def update_location_data():
    user_input = {
        "name": request.form.get("name"),
        "timezone": request.form.get("timezone"),
        "announcementLanguage": request.form.get("announcementLanguage"),
        "preferredLanguage": request.form.get("preferredLanguage"),
        "address": {
            "address1": request.form.get("address1"),
            "address2": request.form.get("address2"),
            "city": request.form.get("city"),
            "state": request.form.get("state"),
            "postalCode": request.form.get("postalCode"),
            "country": request.form.get("country")
        }
    }

    input_file_path = 'D:\Flask\Webexproj\python_files\Input.py' #'Webexproj/Input.py'
    try:
        # Load the Python script as a module
        input_module = SourceFileLoader('input_module', input_file_path).load_module()

        # Replace the entire block containing CreateLocationdata with new data
        with open(input_file_path, 'r') as input_file:
            lines = input_file.readlines()

        with open(input_file_path, 'w') as input_file:
            inside_create_location_data = False

            for line in lines:
                if line.strip().startswith("CreateLocationdata"):
                    inside_create_location_data = True
                    # Write the new CreateLocationdata block
                    input_file.write(f'CreateLocationdata = {json.dumps(user_input, indent=4)}\n')
                elif inside_create_location_data and line.strip() == "}}":
                    # End of the CreateLocationdata block
                    inside_create_location_data = False
                elif not inside_create_location_data:
                    # Write lines outside the CreateLocationdata block
                    input_file.write(line)

        result = "Location data updated successfully."
    except Exception as e:
        result = f"Error: {str(e)}"

    return render_template('update_result.html', result=result)




if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=8444)

